import bcrypt from "bcryptjs";
import mongoose, { Schema, model, models } from "mongoose";


export interface IUser {
    email: string;
    password: string;
    _id?: mongoose.Types.ObjectId;
    createdAt?: Date;
    updatedAt?: Date;
}

const userSchema = new Schema<IUser>(
    {
        email: {
            type: String,
            required: true
        },
        password: {
            type: String,
            required: true
        }
    },
    { timestamps: true }
);


userSchema.pre('save', async function (this: mongoose.Document & IUser, next) {
    if (this.isModified("password"))
        this.password = await bcrypt.hash(this.password, 5);
    next();
})


const User = models?.User || model<IUser>("User", userSchema);
export default User;
